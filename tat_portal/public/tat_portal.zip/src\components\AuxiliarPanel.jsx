import React, { useState, useEffect } from 'react';
import { UploadCloud, CheckCircle2, Image as ImageIcon, FileText, Loader2, Camera, Banknote, Hash, ChevronRight, ArrowLeft, History, Clock } from 'lucide-react';
import { mockDB } from '../lib/supabase';
import toast from 'react-hot-toast';
import imageCompression from 'browser-image-compression';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

// BANCOS_PRIMARY simplified and TAT-aware
const BANCOS_PRIMARY = [
  { id: 'bancolombia_tat', label: 'Bancolombia TAT 4247', sub: 'Cta. 4247', color: '#ffd166', bg: 'rgba(255,209,102,0.12)', emoji: '🟡', value: 'Bancolombia TAT 4247' },
  { id: 'davivienda_tat', label: 'DAVIVIENDA TAT 8283', sub: 'Cta. 8283', color: '#ff4d6d', bg: 'rgba(255,77,109,0.12)', emoji: '🔴', value: 'DAVIVIENDA TAT 8283' },
  { id: 'buzon_atlas', label: 'Buzon Atlas', sub: 'Depósito buzón Atlas', color: '#00e5a0', bg: 'rgba(0,229,160,0.12)', emoji: '📬', value: 'Buzon Atlas' },
  { id: 'gasto', label: 'Gasto', sub: 'Legalización gasto', color: '#ff9f1c', bg: 'rgba(255,159,28,0.12)', emoji: '💸', value: 'Gasto' },
  { id: 'retencion', label: 'Retención', sub: 'Legalización ret.', color: '#94a3b8', bg: 'rgba(148,163,184,0.12)', emoji: '📄', value: 'Retención' },
];

const AuxiliarPanel = ({ user }) => {
  const [primarySelected, setPrimarySelected] = useState(null);
  const [banco, setBanco] = useState('');
  const [showSub, setShowSub] = useState(false);
  const [valor, setValor] = useState('');
  const [numero, setNumero] = useState('');
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [compressing, setCompressing] = useState(false);
  const [history, setHistory] = useState([]);
  const [loadingHistory, setLoadingHistory] = useState(true);
  const [editingItem, setEditingItem] = useState(null);
  const [filterStart, setFilterStart] = useState('');
  const [filterEnd, setFilterEnd] = useState('');
  const [filteredHistory, setFilteredHistory] = useState([]);

  const checkDuplicate = async (numero_comprobante) => {
    const isDuplicate = await mockDB.checkDuplicate(numero_comprobante);
    return isDuplicate;
  };

  const fetchHistory = async () => {
    try {
      const data = await mockDB.getConsignaciones();
      const userHistory = data.filter(c => c.auxiliar_id === user.id);
      setHistory(userHistory);
    } catch (err) { console.error(err); } finally { setLoadingHistory(false); }
  };

  useEffect(() => { fetchHistory(); const interval = setInterval(fetchHistory, 30000); return () => clearInterval(interval); }, [user.id]);

  useEffect(() => {
    if (!filterStart && !filterEnd) { setFilteredHistory(history); return; }
    const start = filterStart ? new Date(filterStart) : null;
    const end = filterEnd ? new Date(filterEnd) : null;
    const filtered = history.filter(item => {
      const itemDate = new Date(item.fecha);
      if (start && itemDate < start) return false;
      if (end) { const endOfDay = new Date(end); endOfDay.setHours(23,59,59,999); if (itemDate > endOfDay) return false; }
      return true;
    });
    setFilteredHistory(filtered);
  }, [history, filterStart, filterEnd]);

  const formatCurrency = (val) => { const clean = val.replace(/\D/g, ''); if (!clean) return ''; return new Intl.NumberFormat('es-CO').format(parseInt(clean, 10)); };
  const handleValorChange = (e) => setValor(formatCurrency(e.target.value));

  const handleFileChange = async (e) => {
    if (e.target.files?.[0]) {
      const orig = e.target.files[0];
      if (orig.type.startsWith('image/')) {
        setCompressing(true);
        const options = { maxSizeMB: 0.2, maxWidthOrHeight: 1280, useWebWorker: true, initialQuality: 0.6 };
        try { const compressed = await imageCompression(orig, options); setFile(compressed); toast.success('Imagen optimizada (Ultra-ligera) ⚡'); } catch { setFile(orig); } finally { setCompressing(false); }
      } else { setFile(orig); }
    }
  };

  const handlePrimarySelect = (b) => { setPrimarySelected(b); if (b.children) { setBanco(''); setShowSub(true); } else { setBanco(b.value); setShowSub(false); } };
  const handleSubSelect = (child) => setBanco(child.value);
  const handleBack = () => { setPrimarySelected(null); setBanco(''); setShowSub(false); };

  const [modal, setModal] = useState(null);

  const handleEditClick = (item) => {
    setEditingItem(item); setBanco(item.banco); setValor(new Intl.NumberFormat('es-CO').format(item.valor)); setNumero(item.numero_comprobante || ''); setFile(null);
    const primary = BANCOS_PRIMARY.find(b => b.value === item.banco || (b.children && b.children.some(c => c.value === item.banco)));
    if (primary) { setPrimarySelected(primary); if (primary.children) setShowSub(true); }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCancelEdit = () => { setEditingItem(null); reset(); };

  const handleSubmit = async (e) => {
    if (e) e.preventDefault();
    const isSpecial = banco === 'Gasto' || banco === 'Retención' || banco === 'Gasto' || banco === 'Retención';
    let finalNumero = numero;
    if (isSpecial && !numero) finalNumero = `${banco.toUpperCase()}-${Date.now()}`;
    const isFileRequired = !editingItem;
    if (!banco || !valor || (!finalNumero && !isSpecial) || (isFileRequired && !file)) {
      const missing = []; if (!banco) missing.push('Banco'); if (!valor) missing.push('Valor'); if (!finalNumero && !isSpecial) missing.push('Número'); if (isFileRequired && !file) missing.push('Foto/PDF');
      setModal({ title: 'Faltan Datos', message: 'Por favor completa: ' + missing.join(', '), icon: '📝', color: 'var(--neon-yellow)' });
      return;
    }

    const valorNumerico = parseInt(valor.replace(/\./g, ''), 10);
    if (isNaN(valorNumerico)) { setModal({ title: 'Valor Inválido', message: 'El valor ingresado no es un número válido.', icon: '❌', color: 'var(--neon-red)' }); return; }

    setLoading(true); const tid = toast.loading('Verificando datos...');
    try {
      const isDuplicate = await mockDB.checkDuplicate(finalNumero, editingItem?.id);
      if (isDuplicate) { toast.dismiss(tid); setModal({ title: '¡Comprobante Repetido!', message: `El número de comprobante "${finalNumero}" ya fue registrado anteriormente.\nUsa un número de comprobante diferente.`, icon: '⚠️', color: 'var(--neon-red)' }); setLoading(false); return; }
      let publicUrl = editingItem ? editingItem.file_url : null;
      if (file) { toast.loading('Subiendo comprobante...', { id: tid }); publicUrl = await mockDB.uploadFile(file); }
      if (editingItem) {
        toast.loading('Actualizando consignación...', { id: tid }); await mockDB.updateConsignacion(editingItem.id, { banco, valor: valorNumerico, numero_comprobante: finalNumero, file_url: publicUrl, estado: 'Pendiente', motivo_rechazo: null }); toast.success('¡Consignación corregida! Volverá a ser revisada. 🌟', { id: tid }); setEditingItem(null); reset();
      } else {
        toast.loading('Guardando consignación...', { id: tid }); await mockDB.addConsignacion({ banco, valor: valorNumerico, numero_comprobante: finalNumero, file_url: publicUrl, auxiliar_id: user.id, auxiliar_name: user.full_name, empresa: 'TAT' }); toast.success('¡Consignación registrada correctamente! 🎉', { id: tid }); setSuccess(true);
      }
    } catch (err) { console.error(err); toast.dismiss(tid); toast.error('❌ Error: ' + (err.message || 'No se pudo guardar la consignación')); } finally { setLoading(false); fetchHistory(); }
  };

  const reset = () => { setSuccess(false); setPrimarySelected(null); setBanco(''); setShowSub(false); setValor(''); setNumero(''); setFile(null); };

  if (success) return (<div className="success-screen animate-in"><div className="success-icon-wrap"><CheckCircle2 size={44} color="var(--neon-green)" /></div><h2 style={{ marginBottom: '0.5rem' }}>¡Consignación Enviada!</h2><p style={{ maxWidth: 260, margin: '0 auto 0.5rem' }}>Registrado en <strong style={{ color: 'var(--text-1)' }}>{banco}</strong></p><p style={{ maxWidth: 260, margin: '0 auto 2rem', fontSize: '0.8rem' }}>Pendiente de validación por la cajera.</p><button className="btn btn-primary" onClick={reset}>Registrar otra</button></div>);

  const today = new Date().toLocaleDateString('es-CO', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div className="page animate-in">
      <div className="hero-card"><div className="hero-label">📅 {today}</div><div className="hero-value" style={{ fontSize: '1.4rem', marginTop: '0.25rem' }}>Nueva Consignación</div><div className="hero-sub">Registra el comprobante para validación 🏦</div></div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '1.5rem' }}>
        <div className="card" style={{ padding: '0.8rem', borderLeft: '3px solid var(--neon-blue)' }}>
          <p style={{ fontSize: '0.65rem', textTransform: 'uppercase', color: 'var(--text-3)', fontWeight: 700 }}>Total Enviado</p>
          <p style={{ fontSize: '1rem', fontWeight: 800, color: 'var(--text-1)' }}>{new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(history.reduce((acc, curr) => acc + curr.valor, 0))}</p>
        </div>
        <div className="card" style={{ padding: '0.8rem', borderLeft: '3px solid var(--neon-yellow)' }}>
          <p style={{ fontSize: '0.65rem', textTransform: 'uppercase', color: 'var(--text-3)', fontWeight: 700 }}>Pendientes</p>
          <p style={{ fontSize: '1rem', fontWeight: 800, color: 'var(--text-1)' }}>{history.filter(c => c.estado === 'Pendiente').length} {history.filter(c => c.estado === 'Pendiente').length === 1 ? 'registro' : 'registros'}</p>
        </div>
      </div>

      <div className="section-header">{showSub ? (<button type="button" onClick={handleBack} style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', background: 'none', border: 'none', color: 'var(--neon-blue)', fontFamily: 'inherit', fontWeight: 700, fontSize: '0.85rem', cursor: 'pointer' }}><ArrowLeft size={15} /> Volver a bancos</button>) : (<span className="section-title">Selecciona el banco</span>)}{banco && (<span style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--neon-green)', background: 'rgba(0,229,160,0.1)', border: '1px solid rgba(0,229,160,0.25)', padding: '2px 10px', borderRadius: '99px' }}>✓ {banco}</span>)}</div>

      {!showSub && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.625rem', marginBottom: '1.25rem' }}>
          {BANCOS_PRIMARY.map(b => {
            const isSelected = primarySelected?.id === b.id;
            return (
              <button key={b.id} type="button" onClick={() => handlePrimarySelect(b)} style={{ padding: '1rem 0.75rem', borderRadius: 'var(--radius-md)', background: isSelected ? b.bg : 'var(--bg-card)', border: `2px solid ${isSelected ? b.color : 'var(--border)'}`, color: isSelected ? b.color : 'var(--text-2)', fontFamily: 'inherit', fontWeight: 700, fontSize: '0.85rem', cursor: 'pointer', transition: 'all 0.2s var(--ease)', textAlign: 'left', transform: isSelected ? 'scale(1.02)' : 'scale(1)', display: 'flex', flexDirection: 'column', gap: '0.2rem' }}>
                <span style={{ fontSize: '1.3rem', lineHeight: 1 }}>{b.emoji}</span>
                <span>{b.label}</span>
                <span style={{ fontSize: '0.68rem', fontWeight: 500, color: isSelected ? b.color : 'var(--text-3)', display: 'flex', alignItems: 'center', gap: 2 }}>{b.sub}{b.children && <ChevronRight size={11} />}</span>
              </button>
            );
          })}
        </div>
      )}

      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.875rem' }}>
        <div>
          <label className="form-label"><Banknote size={12} style={{ display: 'inline', marginRight: 4 }} />Valor Consignado ($)</label>
          <input type="text" inputMode="numeric" className="form-control" placeholder="0" value={valor} onChange={handleValorChange} style={{ fontSize: '1.1rem', fontWeight: 700 }} required />
        </div>

        {!(banco === 'Gasto' || banco === 'Retención') && (
          <div>
            <label className="form-label"><Hash size={12} style={{ display: 'inline', marginRight: 4 }} />Número de Comprobante</label>
            <input type="text" className="form-control" placeholder="Ej. 987654321" value={numero} onChange={e => setNumero(e.target.value)} required />
          </div>
        )}

        <div>
          <label className="form-label"><Camera size={12} style={{ display: 'inline', marginRight: 4 }} />Foto o PDF del Comprobante</label>
          <label className={`file-drop ${file ? 'has-file' : ''}`} style={{ display: 'block', cursor: compressing ? 'not-allowed' : 'pointer', opacity: compressing ? 0.6 : 1 }}>
            <input type="file" accept="image/*,.pdf" onChange={handleFileChange} disabled={compressing} />
            {compressing ? (<div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem' }}><Loader2 size={32} style={{ color: 'var(--neon-blue)', animation: 'spin 0.7s linear infinite' }} /><span style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--neon-blue)' }}>Optimizando...</span></div>) : file ? (<div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.4rem' }}>{file.type.includes('pdf') ? <FileText size={32} color="var(--neon-green)" /> : <ImageIcon size={32} color="var(--neon-green)" />}<span style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--neon-green)', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{file.name}</span><span style={{ fontSize: '0.72rem', color: 'var(--text-2)' }}>{(file.size / 1024 / 1024).toFixed(2)} MB · Toca para cambiar</span></div>) : (<div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem' }}><UploadCloud size={36} style={{ color: 'var(--text-2)' }} /><span style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--text-1)' }}>Tomar foto o subir archivo</span><span style={{ fontSize: '0.75rem', color: 'var(--text-2)' }}>Usa tu cámara o selecciona de la galería</span></div>)}
          </label>
        </div>

        <button type="button" onClick={handleSubmit} className="btn btn-primary w-full" style={{ padding: '1rem', fontSize: '1rem', marginTop: '0.5rem' }} disabled={loading || compressing}>{loading ? <><div className="spinner" /> Guardando...</> : <>Guardar Consignación 🚀</>}</button>
      </form>

      <div className="section-header" style={{ marginTop: '2.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}><History size={18} className="text-blue" /><span className="section-title">Mis Registros</span></div>
      </div>

      <div className="card" style={{ marginBottom: '2rem' }}>
        {loadingHistory ? (<div style={{ display: 'flex', justifyContent: 'center', padding: '2rem' }}><div className="spinner" /></div>) : history.length === 0 ? (<div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-3)' }}><Clock size={32} style={{ marginBottom: '0.75rem', opacity: 0.3 }} /><p style={{ fontSize: '0.85rem' }}>Aún no has enviado consignaciones</p></div>) : filteredHistory.length === 0 ? (<div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-3)' }}><Clock size={32} style={{ marginBottom: '0.75rem', opacity: 0.3 }} /><p style={{ fontSize: '0.85rem' }}>No hay registros en el rango de fechas seleccionado</p></div>) : (<div style={{ display: 'flex', flexDirection: 'column' }}><div style={{ fontSize: '0.75rem', color: 'var(--text-3)', padding: '0.75rem 0', textAlign: 'center', borderBottom: '1px solid var(--border)' }}>Mostrando {filteredHistory.length} de {history.length} registros</div>{filteredHistory.map((item) => (<div key={item.id} className="consign-item" style={{ borderBottom: '1px solid var(--border)', padding: '1rem 0' }}><div style={{ flex: 1 }}><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.25rem' }}><span style={{ fontSize: '0.9rem', fontWeight: 700, color: 'var(--text-1)' }}>{item.banco}</span><span style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--text-1)' }}>{new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(item.valor)}</span></div><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}><div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}><span style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>Comprobante: {item.numero_comprobante}</span><span style={{ fontSize: '0.72rem', color: 'var(--text-3)' }}>{format(new Date(item.fecha), "d MMM, h:mm a", { locale: es })}</span></div><span className={`badge ${item.estado === 'Pendiente' ? 'badge-pending' : item.estado === 'Validado' ? 'badge-validated' : item.estado === 'Cuadrado' ? 'badge-squared' : 'badge-rejected'}`} style={{ fontSize: '0.6rem', padding: '2px 8px' }}>{item.estado}</span></div>{item.motivo_rechazo && (<div style={{ marginTop: '0.5rem', padding: '0.5rem', background: 'rgba(255,77,109,0.05)', borderRadius: '6px', borderLeft: '2px solid var(--neon-red)' }}><p style={{ fontSize: '0.7rem', color: 'var(--neon-red)' }}><strong>Rechazado:</strong> {item.motivo_rechazo}</p></div>)}{item.estado !== 'Validado' && item.estado !== 'Cuadrado' && (<div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '0.5rem' }}><button type="button" onClick={() => handleEditClick(item)} className="btn btn-ghost" style={{ fontSize: '0.7rem', padding: '4px 10px', height: 'auto', display: 'flex', alignItems: 'center', gap: '4px', border: '1px dashed var(--border)', borderRadius: '6px' }}>✏️ Corregir datos</button></div>)}</div></div>))}</div>)}
      </div>

      {modal && (<div className="modal-overlay" style={{ alignItems: 'center', padding: '1.5rem' }}><div className="card animate-in" style={{ maxWidth: '380px', width: '100%', textAlign: 'center', padding: '2rem', background: 'rgba(20, 20, 35, 0.95)', backdropFilter: 'blur(20px)', border: `1px solid ${modal.color}33`, boxShadow: `0 20px 50px -10px rgba(0,0,0,0.5), 0 0 20px ${modal.color}11` }}><div style={{ fontSize: '3rem', marginBottom: '1rem', filter: `drop-shadow(0 0 10px ${modal.color}44)` }}>{modal.icon}</div><h2 style={{ color: modal.color, marginBottom: '0.75rem', fontSize: '1.4rem' }}>{modal.title}</h2><p style={{ color: 'var(--text-1)', marginBottom: '1.5rem', whiteSpace: 'pre-line', fontSize: '0.95rem' }}>{modal.message}</p><button className="btn w-full" onClick={() => setModal(null)} style={{ background: modal.color, color: '#000', boxShadow: `0 0 20px ${modal.color}44` }}>Entendido</button></div></div>)}
    </div>
  );
};

export default AuxiliarPanel;